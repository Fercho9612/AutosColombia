create definer = root@localhost view v_vehiculos_activos as
select `r`.`id`                                         AS `id`,
       `r`.`placa_vehiculo`                             AS `placa_vehiculo`,
       `r`.`id_celda`                                   AS `id_celda`,
       `r`.`hora_entrada`                               AS `hora_entrada`,
       timestampdiff(MINUTE, `r`.`hora_entrada`, now()) AS `minutos_permanencia`,
       `c`.`tipo`                                       AS `tipo_celda`,
       `u`.`nombre`                                     AS `registrado_por`
from ((`parqueadero_db`.`registro` `r` join `parqueadero_db`.`celda` `c`
       on ((`r`.`id_celda` = `c`.`id`))) join `parqueadero_db`.`usuario` `u` on ((`r`.`id_usuario` = `u`.`id`)))
where (`r`.`hora_salida` is null);

-- comment on column v_vehiculos_activos.hora_entrada not supported: Automática — RF09

-- comment on column v_vehiculos_activos.registrado_por not supported: Nombre de acceso al sistema

